-- E-commerce Business Analytics
-- PostgreSQL / MySQL-style queries

-- 1. Total sales, profit and orders
SELECT
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    COUNT(DISTINCT Order_ID) AS total_orders,
    SUM(Quantity) AS units_sold
FROM ecommerce_sales;

-- 2. Sales and profit by category
SELECT
    Category,
    ROUND(SUM(Sales), 2) AS sales,
    ROUND(SUM(Profit), 2) AS profit,
    SUM(Quantity) AS units
FROM ecommerce_sales
GROUP BY Category
ORDER BY sales DESC;

-- 3. Regional performance
SELECT
    Region,
    COUNT(DISTINCT Order_ID) AS orders,
    ROUND(SUM(Sales), 2) AS sales,
    ROUND(SUM(Profit), 2) AS profit
FROM ecommerce_sales
GROUP BY Region
ORDER BY sales DESC;

-- 4. Top 10 products by sales
SELECT
    Product,
    Category,
    ROUND(SUM(Sales), 2) AS sales,
    ROUND(SUM(Profit), 2) AS profit
FROM ecommerce_sales
GROUP BY Product, Category
ORDER BY sales DESC
LIMIT 10;

-- 5. Discount impact
SELECT
    Discount,
    ROUND(SUM(Sales), 2) AS sales,
    ROUND(SUM(Profit), 2) AS profit,
    ROUND(100.0 * SUM(Profit) / NULLIF(SUM(Sales),0), 2) AS profit_margin_pct
FROM ecommerce_sales
GROUP BY Discount
ORDER BY Discount;

-- 6. Monthly trend
SELECT
    EXTRACT(YEAR FROM Order_Date) AS year,
    EXTRACT(MONTH FROM Order_Date) AS month,
    ROUND(SUM(Sales), 2) AS sales,
    ROUND(SUM(Profit), 2) AS profit
FROM ecommerce_sales
GROUP BY year, month
ORDER BY year, month;
